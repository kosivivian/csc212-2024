#pragma once
class ball
{
};

